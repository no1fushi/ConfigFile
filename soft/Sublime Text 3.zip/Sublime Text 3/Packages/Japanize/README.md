sublimetext_japanize
====================

Japanese menu for Sublime Text 3  
  
Sublime Text 3の日本語化プラグインです。  
[ゆーがいぶろぐ](http://blog.huwy.org/article/292827228.html)さんの日本語化ファイルがベースです。  
  
適用手順  
１．C:\Users\ユーザー名\AppData\Roaming\Sublime Text 3\Packages\Japanizeにインストールされている*.jpファイルを、  
 　　　C:\Users\ユーザー名\AppData\Roaming\Sublime Text 3\Packages\Default  
　　にコピーします。※Defaultフォルダがない場合は作成してください。  
２．コピーしたファイルをオリジナルのファイル（.jpが付かないファイル）と置き換えます。（念のため、オリジナルのファイルが有る場合は.orgなどを付けて保管しておきましょう。）  
３．C:\Users\ユーザー名\AppData\Roaming\Sublime Text 3\Packages\Japanize\Main.sublime-menu（.jpが付かない方）を、  
 　　　C:\Users\ユーザー名\AppData\Roaming\Sublime Text 3\Packages\User  
　　にコピーします。すると、他のプラグインで上書きされてしまっているトップメニューも日本語化されます。  

※Mac OSでは/Users/ユーザー名/Library/Application Support/Sublime Text 3/Packages/*に読み替えてください。  

以上です。  