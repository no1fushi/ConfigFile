"""File Strip."""
